from django.shortcuts import render
from django.http import HttpResponse

from datetime import datetime

def index(request):
    now = datetime.now()

    return render(
        request,
        "MyApp1/about.html",  # Relative path from the 'templates' folder to the template file
        # "index.html", # Use this code for VS 2017 15.7 and earlier
        {
            'title' : "About HelloDjangoApp",
            'content' : "Example app page for Django."
        }
    )