from django.apps import AppConfig


class MyApp1Config(AppConfig):
    name = 'MyApp1'
