"""
Package for BasicProject.
"""
