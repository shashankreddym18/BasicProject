"""
Package for DjangoWeb.
"""
